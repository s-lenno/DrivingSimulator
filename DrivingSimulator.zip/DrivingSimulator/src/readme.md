The real "0. About this game."

"DRIVING", is a basic text-based Java console application that simulates the experience of owning and driving a car.
The game features car maintencance, decision-making, and random events, creating an engaging and interactive experience in a simple text-based environment.
You, as the player, have the opportunity to interact with various features related to your virtual car, including:
- Starting the car
- Driving the car with a random event system during driving, such as encountering traffic, getting a speed boost, or finding shortcuts
- Describing the car and its engine type
- Stopping the car
- Refueling to manage your car's fuel level
- Upgrading the car 
- Showing the total distance traveled by your car
- Monitoring points earned based on your driving performance
- Having the option to exit the game whenever you're ready

